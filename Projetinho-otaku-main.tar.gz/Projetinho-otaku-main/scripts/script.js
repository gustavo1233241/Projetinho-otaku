interruptor = true
interruptor1 = true
var box_OffCavas = document.getElementById('box')
var Fechar_OffCavas = document.getElementById('fecha_Box')

function btnOffcanvas() {

    if (interruptor) {

        box_OffCavas.style.width = '30vw';
        box_OffCavas.style.display = 'block';
        Fechar_OffCavas.style.display = 'block'

        interruptor = false


    }
    else {
        box_OffCavas.style.width = '0vw';
        box_OffCavas.style.display = 'none';
        Fechar_OffCavas.style.display = 'none'


        interruptor = true

    }

}

var estrela1 = document.getElementById('estrela1')
var estrela2 = document.getElementById('estrela2')
var estrela3 = document.getElementById('estrela3')
var estrela4 = document.getElementById('estrela4')
var estrela5 = document.getElementById('estrela5')
var estrela6 = document.getElementById('estrela6')
var estrela7 = document.getElementById('estrela7')
var estrela8 = document.getElementById('estrela8')
var estrela9 = document.getElementById('estrela9')
var estrela10 = document.getElementById('estrela10')
var estrela11 = document.getElementById('estrela11')
var estrela12 = document.getElementById('estrela12')
var estrela13 = document.getElementById('estrela13')
var estrela14 = document.getElementById('estrela14')
var estrela15 = document.getElementById('estrela15')
var estrela16 = document.getElementById('estrela16')
var estrela17 = document.getElementById('estrela17')
var estrela18 = document.getElementById('estrela18')
var estrela19 = document.getElementById('estrela19')
var estrela20 = document.getElementById('estrela20')
var estrela21 = document.getElementById('estrela21')

function estrelas() {
    if (interruptor) {
        estrela2.style.color = 'rgb(45, 46, 41)';
        estrela3.style.color = 'rgb(45, 46, 41)';
        estrela4.style.color = 'rgb(45, 46, 41)';
        estrela5.style.color = 'rgb(45, 46, 41)';
        interruptor = true
    }
}
function Tira_estrelas() {
    if (interruptor) {
        estrela2.style.color = 'yellow';
        estrela3.style.color = 'yellow';
        estrela4.style.color = 'yellow';
        estrela5.style.color = 'yellow';
        interruptor = true
    }
}
function estrelas2() {
    if (interruptor) {
        estrela3.style.color = 'rgb(45, 46, 41)';
        estrela4.style.color = 'rgb(45, 46, 41)';
        estrela5.style.color = 'rgb(45, 46, 41)';
        interruptor = true
    }
}
function Tira_estrelas2() {
    if (interruptor) {
        estrela3.style.color = 'yellow';
        estrela4.style.color = 'yellow';
        estrela5.style.color = 'yellow';
        interruptor = true
    }
}
function estrelas3() {
    if (interruptor) {
        estrela4.style.color = 'rgb(45, 46, 41)';
        estrela5.style.color = 'rgb(45, 46, 41)';
        interruptor = true
    }
}
function Tira_estrelas3() {

    if (interruptor) {
        estrela4.style.color = 'yellow';
        estrela5.style.color = 'yellow';
        interruptor = true
    }
}
function estrelas4() {

    if (interruptor) {
        estrela5.style.color = 'rgb(45, 46, 41)';
        interruptor = true
    }
}
function Tira_estrelas4() {
    if (interruptor) {
        estrela5.style.color = 'yellow';
        interruptor = true
    }
}

function estrelas5() {

    if (interruptor) {
        estrela6.style.color = 'rgb(45, 46, 41)';
        estrela7.style.color = 'rgb(45, 46, 41)';
        estrela8.style.color = 'rgb(45, 46, 41)';
        estrela9.style.color = 'rgb(45, 46, 41)';
        interruptor = true
    }
}
function Tira_estrelas5() {
    if (interruptor) {
        estrela6.style.color = 'yellow';
        estrela7.style.color = 'yellow';
        estrela8.style.color = 'yellow';
        estrela9.style.color = 'yellow';
        interruptor = true
    }
}

function estrelas6() {

    if (interruptor) {

        estrela7.style.color = 'rgb(45, 46, 41)';
        estrela8.style.color = 'rgb(45, 46, 41)';
        estrela9.style.color = 'rgb(45, 46, 41)';
        interruptor = true
    }
}
function Tira_estrelas6() {
    if (interruptor) {
        estrela7.style.color = 'yellow';
        estrela8.style.color = 'yellow';
        estrela9.style.color = 'yellow';
        interruptor = true
    }
}

function estrelas7() {

    if (interruptor) {


        estrela8.style.color = 'rgb(45, 46, 41)';
        estrela9.style.color = 'rgb(45, 46, 41)';
        interruptor = true
    }
}
function Tira_estrelas7() {
    if (interruptor) {


        estrela8.style.color = 'yellow';
        estrela9.style.color = 'yellow';
        interruptor = true
    }
}

function estrelas8() {

    if (interruptor) {



        estrela9.style.color = 'rgb(45, 46, 41)';
        interruptor = true
    }
}
function Tira_estrelas8() {
    if (interruptor) {



        estrela9.style.color = 'yellow';
        interruptor = true
    }
}

function estrelas9() {

    if (interruptor) {
        estrela10.style.color = 'rgb(45, 46, 41)';
        estrela11.style.color = 'rgb(45, 46, 41)';
        estrela12.style.color = 'rgb(45, 46, 41)';
        estrela13.style.color = 'rgb(45, 46, 41)';
        interruptor = true
    }
}
function Tira_estrelas9() {
    if (interruptor) {
        estrela10.style.color = 'yellow';
        estrela11.style.color = 'yellow';
        estrela12.style.color = 'yellow';
        estrela13.style.color = 'yellow';
        interruptor = true
    }
}


function estrelas10() {

    if (interruptor) {

        estrela11.style.color = 'rgb(45, 46, 41)';
        estrela12.style.color = 'rgb(45, 46, 41)';
        estrela13.style.color = 'rgb(45, 46, 41)';
        interruptor = true
    }
}
function Tira_estrelas10() {
    if (interruptor) {

        estrela11.style.color = 'yellow';
        estrela12.style.color = 'yellow';
        estrela13.style.color = 'yellow';
        interruptor = true
    }
}

function estrelas11() {

    if (interruptor) {

        estrela12.style.color = 'rgb(45, 46, 41)';
        estrela13.style.color = 'rgb(45, 46, 41)';
        interruptor = true
    }
}
function Tira_estrelas11() {
    if (interruptor) {


        estrela12.style.color = 'yellow';
        estrela13.style.color = 'yellow';
        interruptor = true
    }
}


function estrelas12() {

    if (interruptor) {


        estrela13.style.color = 'rgb(45, 46, 41)';
        interruptor = true
    }
}
function Tira_estrelas12() {
    if (interruptor) {

        estrela13.style.color = 'yellow';
        interruptor = true
    }
}

function estrelas13() {

    if (interruptor) {
        
        estrela14.style.color = 'rgb(45, 46, 41)';
        estrela15.style.color = 'rgb(45, 46, 41)';
        estrela16.style.color = 'rgb(45, 46, 41)';
        estrela17.style.color = 'rgb(45, 46, 41)';
        
        
        interruptor = true
    }
}
function Tira_estrelas13() {
    if (interruptor) {
        
        estrela14.style.color = 'yellow';
        estrela15.style.color = 'yellow';
        estrela16.style.color = 'yellow';
        estrela17.style.color = 'yellow';
        interruptor = true
    }
}
function estrelas14() {

    if (interruptor) {
        
        
        estrela15.style.color = 'rgb(45, 46, 41)';
        estrela16.style.color = 'rgb(45, 46, 41)';
        estrela17.style.color = 'rgb(45, 46, 41)';
        
        
        interruptor = true
    }
}
function Tira_estrelas14() {
    if (interruptor) {
        
    
        estrela15.style.color = 'yellow';
        estrela16.style.color = 'yellow';
        estrela17.style.color = 'yellow';
        interruptor = true
    }
}
function estrelas15() {

    if (interruptor) {
        
        
       
        estrela16.style.color = 'rgb(45, 46, 41)';
        estrela17.style.color = 'rgb(45, 46, 41)';
        
        
        interruptor = true
    }
}
function Tira_estrelas15() {
    if (interruptor) {
        
    
       
        estrela16.style.color = 'yellow';
        estrela17.style.color = 'yellow';
        interruptor = true
    }
}

function estrelas16() {

    if (interruptor) {
        
        
       
    
        estrela17.style.color = 'rgb(45, 46, 41)';
        
        
        interruptor = true
    }
}
function Tira_estrelas16() {
    if (interruptor) {
        
    
       
        
        estrela17.style.color = 'yellow';
        interruptor = true
    }
}
function estrelas17() {

    if (interruptor) {
        
        
       
    
        estrela18.style.color = 'rgb(45, 46, 41)';
        estrela19.style.color = 'rgb(45, 46, 41)';
        estrela20.style.color = 'rgb(45, 46, 41)';
        estrela21.style.color = 'rgb(45, 46, 41)';
        
        
        interruptor = true
    }
}
function Tira_estrelas17() {
    if (interruptor) {
        
    
       
        
        estrela18.style.color = 'yellow';
        estrela19.style.color = 'yellow';
        estrela20.style.color = 'yellow';
        estrela21.style.color = 'yellow';
        interruptor = true
    }
}
function estrelas18() {

    if (interruptor) {
        
        estrela19.style.color = 'rgb(45, 46, 41)';
        estrela20.style.color = 'rgb(45, 46, 41)';
        estrela21.style.color = 'rgb(45, 46, 41)';
          
        interruptor = true
    }
}
function Tira_estrelas18() {
    if (interruptor) {

    
        estrela19.style.color = 'yellow';
        estrela20.style.color = 'yellow';
        estrela21.style.color = 'yellow';
        interruptor = true
    }
}

function estrelas19() {

    if (interruptor) {
        
        
        estrela20.style.color = 'rgb(45, 46, 41)';
        estrela21.style.color = 'rgb(45, 46, 41)';
          
        interruptor = true
    }
}
function Tira_estrelas19() {
    if (interruptor) {

    
        
        estrela20.style.color = 'yellow';
        estrela21.style.color = 'yellow';
        interruptor = true
    }
}
function estrelas20() {

    if (interruptor) {
        
        
     
        estrela21.style.color = 'rgb(45, 46, 41)';
          
        interruptor = true
    }
}
function Tira_estrelas20() {
    if (interruptor) {

    
        
  
        estrela21.style.color = 'yellow';
        interruptor = true
    }
}















